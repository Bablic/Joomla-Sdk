<?php
######################################################################
# Copyright (C) 2012 by Bablic  	   	   	   	   	   	   	   	   	 #
# Homepage   : www.bablic.com		   	   	   	   	   	   		     #
# Author     : Ishai Jaffe	    		   	   	   	   	   	   	   	 #
# Email      : ishai@bablic.com      	   	   	   	   	   	   	     #
# Version    : 1.0.0                     	   	    	   	   		 #
# License    : http://www.gnu.org/copyleft/gpl.html GNU/GPL          #
######################################################################
defined('_JEXEC') or die('Restricted access');
